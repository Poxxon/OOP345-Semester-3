//==============================================
// Name:           Pouya Rad
// Student Number: 164382228
// Email:          prad@myseneca.ca
// Section:        NDD
//==============================================

#include "settings.h"

namespace seneca {
    Settings g_settings; // Definition of the global settings variable
}
