// house.h

static void display(int key);
void foo(int key);
