// dogcat.h

namespace dog{
  void display();
}

namespace cat{
  void display();
}
